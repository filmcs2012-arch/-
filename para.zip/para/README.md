# Backend W01 - Hello API

โปรเจกต์ตัวอย่างสำหรับวิชา Back-End: สร้างเซิร์ฟเวอร์ Express และ endpoint `/health`

## สเปกเครื่องมือ
- Node.js LTS
- Express
- Nodemon (ช่วงพัฒนา)

## ติดตั้ง
```bash
npm install